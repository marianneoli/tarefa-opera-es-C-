﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            float n1,n2,resultado;
            Console.WriteLine("insira o numero que deseja saber o resultado");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("insira o numero que deseja saber o resultado");
            n2 = Convert.ToInt32(Console.ReadLine());
            resultado = n1 + n2;
            Console.WriteLine(resultado);
            Console.ReadKey();

            Console.WriteLine("insira o primeiro numero");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("insira o segundo numero");
            n2 = Convert.ToInt32(Console.ReadLine());
            resultado = n1 - n2;
            Console.WriteLine(resultado);
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("Insira o primeiro numero");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("insira o segundo numero");
            n2 = Convert.ToInt32(Console.ReadLine());
            resultado = n1 * n2;
            Console.WriteLine(resultado);
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine("Insira o primeiro numero");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("insira o segundo numero");
            n2 = Convert.ToInt32(Console.ReadLine());
            resultado = n1 / n2;
            Console.WriteLine(resultado);
            Console.ReadKey();






        }
    }
}
